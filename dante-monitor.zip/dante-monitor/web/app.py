"""
app.py — Flask web dashboard for Dante Monitor
"""

from flask import Flask, render_template, jsonify
from core.discovery import DanteDiscovery
from core.monitor import DanteMonitor
from utils.config import load_config
import threading
import time

monitor_state = {}


def background_poll(monitor: DanteMonitor, devices: list):
    """Background thread to keep device state updated."""
    while True:
        monitor.update_state(devices)
        monitor_state.update(monitor.device_state)
        time.sleep(monitor.poll_interval)


def create_app(config_path="config.yaml"):
    app = Flask(__name__)
    config = load_config(config_path)

    discovery = DanteDiscovery(config_path)
    monitor = DanteMonitor(config_path)
    devices = discovery.scan()

    # Start background polling thread
    thread = threading.Thread(target=background_poll, args=(monitor, devices), daemon=True)
    thread.start()

    @app.route("/")
    def index():
        return render_template("dashboard.html")

    @app.route("/api/devices")
    def api_devices():
        return jsonify(list(monitor_state.values()))

    return app
