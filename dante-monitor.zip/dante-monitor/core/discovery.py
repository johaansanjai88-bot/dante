"""
discovery.py — mDNS-based Dante device discovery
Uses zeroconf to find _netaudio-arc._udp and _netaudio-cmc._udp services
"""

import socket
import ipaddress
import time
from zeroconf import Zeroconf, ServiceBrowser, ServiceListener
from utils.logger import get_logger
from utils.config import load_config

logger = get_logger(__name__)

DANTE_SERVICE_TYPES = [
    "_netaudio-arc._udp.local.",   # Dante ARC (Audio Routing Control)
    "_netaudio-cmc._udp.local.",   # Dante CMC (Clock Master Control)
]


class DanteListener(ServiceListener):
    def __init__(self):
        self.devices = {}

    def add_service(self, zc: Zeroconf, type_: str, name: str):
        info = zc.get_service_info(type_, name)
        if info:
            ip = socket.inet_ntoa(info.addresses[0]) if info.addresses else "Unknown"
            device_name = name.replace(type_, "").strip(".")
            self.devices[device_name] = {
                "name": device_name,
                "ip": ip,
                "port": info.port,
                "online": True,
                "sample_rate": info.properties.get(b"rate", b"--").decode("utf-8", errors="ignore"),
                "service": type_,
            }
            logger.debug(f"Discovered: {device_name} @ {ip}")

    def remove_service(self, zc: Zeroconf, type_: str, name: str):
        device_name = name.replace(type_, "").strip(".")
        if device_name in self.devices:
            self.devices[device_name]["online"] = False
            logger.debug(f"Device went offline: {device_name}")

    def update_service(self, zc: Zeroconf, type_: str, name: str):
        self.add_service(zc, type_, name)


class DanteDiscovery:
    def __init__(self, config_path="config.yaml"):
        self.config = load_config(config_path)
        self.timeout = self.config.get("network", {}).get("discovery_timeout", 5)

    def scan(self) -> list:
        """Scan network for Dante devices. Returns list of device dicts."""
        zc = Zeroconf()
        listener = DanteListener()
        browsers = [ServiceBrowser(zc, stype, listener) for stype in DANTE_SERVICE_TYPES]

        logger.info(f"Listening for Dante devices ({self.timeout}s)...")
        time.sleep(self.timeout)

        for browser in browsers:
            browser.cancel()
        zc.close()

        devices = list(listener.devices.values())
        logger.info(f"Discovery complete. Found {len(devices)} device(s).")
        return devices
