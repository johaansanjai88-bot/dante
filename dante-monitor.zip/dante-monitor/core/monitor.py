"""
monitor.py — Live polling monitor for Dante devices
Polls discovered devices and tracks online/offline state with timestamps
"""

import time
import os
import socket
from datetime import datetime
from core.discovery import DanteDiscovery
from core.alerts import AlertManager
from utils.logger import get_logger
from utils.config import load_config

logger = get_logger(__name__)


def clear_screen():
    os.system("cls" if os.name == "nt" else "clear")


def ping_device(ip: str, timeout: float = 1.0) -> bool:
    """Quick TCP ping on port 14336 (Dante ARC port)."""
    try:
        with socket.create_connection((ip, 14336), timeout=timeout):
            return True
    except (socket.timeout, ConnectionRefusedError, OSError):
        # Try ICMP-style ping fallback
        response = os.system(f"ping -c 1 -W 1 {ip} > /dev/null 2>&1")
        return response == 0


class DanteMonitor:
    def __init__(self, config_path="config.yaml"):
        self.config = load_config(config_path)
        self.poll_interval = self.config.get("network", {}).get("poll_interval", 5)
        self.offline_threshold = self.config.get("alerts", {}).get("offline_threshold", 10)
        self.discovery = DanteDiscovery(config_path)
        self.alerts = AlertManager(config_path)
        self.device_state = {}

    def update_state(self, devices: list):
        now = time.time()
        for device in devices:
            name = device["name"]
            is_online = ping_device(device["ip"])

            if name not in self.device_state:
                self.device_state[name] = {
                    **device,
                    "last_seen": now if is_online else None,
                    "online": is_online,
                    "downtime_start": None if is_online else now,
                }
            else:
                prev_online = self.device_state[name]["online"]
                self.device_state[name]["online"] = is_online
                if is_online:
                    self.device_state[name]["last_seen"] = now
                    self.device_state[name]["downtime_start"] = None
                    if not prev_online:
                        logger.info(f"✅  {name} came back ONLINE")
                        self.alerts.notify_online(name)
                else:
                    if prev_online:
                        self.device_state[name]["downtime_start"] = now
                        logger.warning(f"⚠️   {name} went OFFLINE")
                        self.alerts.notify_offline(name)

    def render_table(self):
        now = time.time()
        clear_screen()
        print("╔══════════════════════════════════════════════════════════════════╗")
        print("║           🎛️  DANTE NETWORK MONITOR — johaansa                  ║")
        print(f"║  Updated: {datetime.now().strftime('%H:%M:%S')}                                       ║")
        print("╠══════════════════════════════════════════════════════════════════╣")
        print(f"  {'Device':<24} {'IP Address':<17} {'Status':<12} {'Last Seen / Down For'}")
        print(f"  {'─'*70}")

        for name, d in sorted(self.device_state.items()):
            if d["online"]:
                status = "🟢 Online"
                time_info = datetime.fromtimestamp(d["last_seen"]).strftime("%H:%M:%S")
            else:
                status = "🔴 Offline"
                if d["downtime_start"]:
                    secs = int(now - d["downtime_start"])
                    time_info = f"Down {secs}s"
                else:
                    time_info = "Unknown"
            print(f"  {name:<24} {d['ip']:<17} {status:<12} {time_info}")

        print(f"\n  Polling every {self.poll_interval}s  |  Ctrl+C to stop")

    def run(self):
        """Main monitoring loop."""
        logger.info("Starting live monitor. Press Ctrl+C to stop.")
        devices = self.discovery.scan()
        if not devices:
            print("❌  No devices found during initial discovery. Check config.yaml.")
            return

        try:
            while True:
                self.update_state(devices)
                self.render_table()
                time.sleep(self.poll_interval)
        except KeyboardInterrupt:
            print("\n\n👋  Monitor stopped.")
