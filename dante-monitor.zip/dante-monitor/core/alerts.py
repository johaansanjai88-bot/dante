"""
alerts.py — Alert system for Dante device status changes
Supports: console logging, email (SMTP), webhook (Slack/Teams)
"""

import smtplib
import requests
from email.mime.text import MIMEText
from utils.logger import get_logger
from utils.config import load_config

logger = get_logger(__name__)


class AlertManager:
    def __init__(self, config_path="config.yaml"):
        self.config = load_config(config_path).get("alerts", {})
        self.enabled = self.config.get("enabled", False)
        self.email = self.config.get("email", "")
        self.webhook_url = self.config.get("webhook_url", "")
        self.smtp = self.config.get("smtp", {})

    def notify_offline(self, device_name: str):
        if not self.enabled:
            return
        message = f"🔴 DANTE ALERT: Device '{device_name}' went OFFLINE"
        logger.warning(message)
        self._send_email(f"Dante Device Offline: {device_name}", message)
        self._send_webhook(message)

    def notify_online(self, device_name: str):
        if not self.enabled:
            return
        message = f"🟢 DANTE ALERT: Device '{device_name}' is back ONLINE"
        logger.info(message)
        self._send_email(f"Dante Device Online: {device_name}", message)
        self._send_webhook(message)

    def _send_email(self, subject: str, body: str):
        if not self.email or not self.smtp:
            return
        try:
            msg = MIMEText(body)
            msg["Subject"] = subject
            msg["From"] = self.smtp.get("from", "dante-monitor@localhost")
            msg["To"] = self.email

            with smtplib.SMTP(self.smtp.get("host", "localhost"), self.smtp.get("port", 25)) as server:
                if self.smtp.get("tls"):
                    server.starttls()
                if self.smtp.get("username"):
                    server.login(self.smtp["username"], self.smtp["password"])
                server.send_message(msg)
            logger.debug(f"Email alert sent to {self.email}")
        except Exception as e:
            logger.error(f"Failed to send email alert: {e}")

    def _send_webhook(self, message: str):
        if not self.webhook_url:
            return
        try:
            payload = {"text": message}
            requests.post(self.webhook_url, json=payload, timeout=5)
            logger.debug("Webhook alert sent.")
        except Exception as e:
            logger.error(f"Failed to send webhook alert: {e}")
