"""
routing.py — Parse and display Dante audio subscriptions (routing)
Dante routing is queried via the ARC protocol on UDP port 14336
"""

import socket
import struct
from utils.logger import get_logger
from utils.config import load_config
from core.discovery import DanteDiscovery

logger = get_logger(__name__)

DANTE_ARC_PORT = 14336


def query_device_subscriptions(ip: str, device_name: str) -> list:
    """
    Send a basic ARC status query to a Dante device and parse subscription info.
    Returns a list of subscription dicts.
    NOTE: Full ARC protocol implementation requires Audinate licensing.
    This is a simplified stub for educational/open-source use.
    """
    subscriptions = []
    # Placeholder — in production, implement ARC binary protocol
    # or use Dante Controller's automation API
    logger.debug(f"Querying subscriptions for {device_name} @ {ip}")
    return subscriptions


class RoutingParser:
    def __init__(self, config_path="config.yaml"):
        self.config = load_config(config_path)
        self.discovery = DanteDiscovery(config_path)

    def get_subscriptions(self) -> list:
        """
        Discover all devices and collect their subscriptions.
        Returns flat list of subscription records.
        """
        devices = self.discovery.scan()
        all_routes = []

        for device in devices:
            subs = query_device_subscriptions(device["ip"], device["name"])
            for sub in subs:
                all_routes.append({
                    "rx_device": device["name"],
                    "rx_channel": sub.get("rx_channel", "?"),
                    "tx_device": sub.get("tx_device", "?"),
                    "tx_channel": sub.get("tx_channel", "?"),
                })

        if not all_routes:
            logger.info("No subscriptions found (or ARC query not implemented).")
            logger.info("Tip: Use Dante Controller GUI for full routing visibility.")

        return all_routes
