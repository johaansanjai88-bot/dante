"""
exporter.py — Export device list to CSV or JSON
"""

import json
import csv
import os
from utils.logger import get_logger

logger = get_logger(__name__)


class Exporter:
    def save(self, devices: list, filepath: str):
        ext = os.path.splitext(filepath)[1].lower()
        if ext == ".json":
            self._save_json(devices, filepath)
        elif ext == ".csv":
            self._save_csv(devices, filepath)
        else:
            logger.error(f"Unsupported export format: {ext}. Use .json or .csv")

    def _save_json(self, devices: list, filepath: str):
        with open(filepath, "w") as f:
            json.dump(devices, f, indent=2, default=str)
        logger.info(f"Exported JSON → {filepath}")

    def _save_csv(self, devices: list, filepath: str):
        if not devices:
            logger.warning("No devices to export.")
            return
        fieldnames = list(devices[0].keys())
        with open(filepath, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(devices)
        logger.info(f"Exported CSV → {filepath}")
