"""
config.py — Load YAML config file with fallback defaults
"""

import os
import yaml
from utils.logger import get_logger

logger = get_logger(__name__)

DEFAULTS = {
    "network": {
        "subnet": "192.168.1.0/24",
        "poll_interval": 5,
        "discovery_timeout": 5,
    },
    "alerts": {
        "enabled": False,
        "offline_threshold": 10,
        "email": "",
        "webhook_url": "",
        "smtp": {},
    },
    "web": {
        "host": "0.0.0.0",
        "port": 5000,
    },
}


def load_config(path="config.yaml") -> dict:
    if not os.path.exists(path):
        logger.warning(f"Config file '{path}' not found. Using defaults.")
        return DEFAULTS

    with open(path, "r") as f:
        try:
            user_config = yaml.safe_load(f) or {}
        except yaml.YAMLError as e:
            logger.error(f"Error parsing config file: {e}")
            return DEFAULTS

    # Deep merge user config over defaults
    config = DEFAULTS.copy()
    for key, value in user_config.items():
        if isinstance(value, dict) and key in config:
            config[key] = {**config[key], **value}
        else:
            config[key] = value

    return config
